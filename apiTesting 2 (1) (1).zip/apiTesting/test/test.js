
const should = require("should");
const request = require("request");
const expect = require("chai").expect;
const baseUrl = "http://jsonplaceholder.typicode.com/posts/1";
const baseUrlpost = "http://jsonplaceholder.typicode.com/posts/";

const util = require("util");

describe('Json PlaceHolder', function() {
    it('should match get user body', function(done) {
        request.get({ url: baseUrl 
    },
            function(error, response, body) {
            		const bodyObj = JSON.parse(body);
                    expect(response.statusCode).to.equal(200);
                    expect(bodyObj.body).to.equal("quia et suscipit\nsuscipit recusandae consequuntur expedita et cum\nreprehenderit molestiae ut ut quas totam\nnostrum rerum est autem sunt rem eveniet architecto");
                    console.log(bodyObj.body);
                done();
            });      
    });

    it('should match post user id', function(done) {
        request.post({ url: baseUrlpost 
    },
            function(error, response, body) {
            		const bodyObj = JSON.parse(body);
                    expect(response.statusCode).to.equal(201);
                    expect(bodyObj.id).to.equal(101);
                    console.log(bodyObj.id);
                done();
            });
     
    });
    it('should match put user id', function(done) {
        request.put({ url: baseUrl 
    },
            function(error, response, body) {
            		const bodyObj = JSON.parse(body);
                    expect(response.statusCode).to.equal(200);
                    expect(bodyObj.id).to.equal(1);
                    console.log(bodyObj.id);
                done();
            });
     
    });
    it('should match delete user id', function(done) {
        request.delete({ url: baseUrl 
    },
            function(error, response, body) {
            		const bodyObj = JSON.parse(body);
                    expect(response.statusCode).to.equal(200);  
                    console.log(bodyObj);
                done();
            });
     
    });
});