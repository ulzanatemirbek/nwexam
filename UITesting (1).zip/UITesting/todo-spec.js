
describe('angularjs homepage todo list', function() {
    

    it('should login into the site', function() {

        browser.ignoreSynchronization = true;
        browser.get('https://www.saucedemo.com/');
        var loginname = 'standard_user';
        var password = 'secret_sauce';
        var input1 = element(by.id('user-name')).click();
        input1.sendKeys(loginname);
        var input2 = element(by.id('password')).click();
        input2.sendKeys(password);
        var login = $('.btn_action').click();
        var expectedTitle = 'Swag Labs';
        var title = browser.getTitle().then(function(actualTitle){
          expect(actualTitle).toEqual(expectedTitle);
        });

    });
    it('should sort the items', function(){
      var sort = $('.product_sort_container').click();
      var sortitem = element(by.xpath("//option[@value='lohi']")).click();
      var inventoryFirstPrice = element(by.xpath("(//div[@class='inventory_item_price'])[1]")).getText().then(function(item){
        var inventorySecondPrice = element(by.xpath("(//div[@class='inventory_item_price'])[2]")).getText().then(function(item2){
          var inventoryTHirdPrice = element(by.xpath("(//div[@class='inventory_item_price'])[3]")).getText().then(function(item3){
        
            var fetched = item.slice(1,2);
            var fetched2 = item2.slice(1,2);
            var fetched3 = item3.slice(1,3);

              if(fetched<fetched2<fetched3){
                console.log("Success the sort items are sorted from low to high prices")
              }else{
                console.log("Fail")
              }
          })
        }); 
        
      });

    })

    it('should Visit the shopping card and verify the add functionality',function(){

      var addOneITem = element(by.xpath("(//button[@class='btn_primary btn_inventory'])[1]")).click();
      var addSecondITem = element(by.xpath("(//button[@class='btn_primary btn_inventory'])[2]")).click();

      var shoppingCard = $('.shopping_cart_container').click();
      
      element(by.xpath("(//div[@class='inventory_item_name'])[1]")).getText().then(function(item){
        element(by.xpath("(//div[@class='inventory_item_name'])[2]")).getText().then(function(item2){
          var expectedItem1 = 'Sauce Labs Onesie'
          var expectedItem2 = 'Sauce Labs Bolt T-Shirt'
          
          expect(item).toEqual(expectedItem1);
          expect(item2).toEqual(expectedItem2);

           
     
          
        })
      }) 
    })

    it('should remove the item from the shopping card', function(){
      element(by.xpath("(//button[@class='btn_secondary cart_button'])[1]")).click()
      element(by.xpath("//a[@class='btn_secondary']")).click();      
      element(by.xpath("(//button[@class='btn_primary btn_inventory'])[1]")).click();  
      var shoppingCard = $('.shopping_cart_container').click();
      element(by.xpath("//a[@class='btn_action checkout_button']")).click(); 
      element(by.xpath("//input[@id='first-name']")).sendKeys("Mike"); 
      element(by.xpath("//input[@id='last-name']")).sendKeys("Smith"); 
      element(by.xpath("//input[@id='postal-code']")).sendKeys("10000");        

      element(by.xpath("//input[@class='btn_primary cart_button']")).click();

      element(by.xpath("//div[@class='summary_total_label']")).getText().then(function(totalPrice){
        
      var expectedTotalMessage = 'Total: $49.66';
      expect(totalPrice).toEqual(expectedTotalMessage);
      element(by.xpath("//a[@class='btn_action cart_button']")).click().then(function(finish){
        element(by.xpath("//h2[@class='complete-header']")).getText().then(function(finish2){
          console.log(finish2);
          var finishExpected = 'THANK YOU FOR YOUR ORDER';
          expect(finish2).toEqual(finishExpected);
        })

      
      });
    
      })
      



      
      
        browser.sleep(10000)
      })
    })
  

  